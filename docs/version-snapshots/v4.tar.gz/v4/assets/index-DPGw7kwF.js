import{C as e,t}from"./jsx-runtime-BG15XL8J.js";import{U as n}from"./DocPage-eJB4XYt0-C-ATeIh7.js";import{t as r}from"./provider-CAkBtBaM.js";var i=t(),a=[{id:`components`,text:`Components`,level:2},{id:`functions`,text:`Functions`,level:2},{id:`type-aliases`,text:`Type Aliases`,level:2}],o={title:`API Reference`,description:`Auto-generated API documentation`,sidebar_position:0};function s(e){let t={a:`a`,h2:`h2`,li:`li`,ul:`ul`,...r(),...e.components};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(t.h2,{id:`components`,children:`Components`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardocodeblock`,children:`ArdoCodeBlock`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardocodegroup`,children:`ArdoCodeGroup`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardocontainer`,children:`ArdoContainer`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardocontent`,children:`ArdoContent`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardocopybutton`,children:`ArdoCopyButton`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardodanger`,children:`ArdoDanger`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardodoclayout`,children:`ArdoDocLayout`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardodocpage`,children:`ArdoDocPage`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardofeaturecard`,children:`ArdoFeatureCard`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardofeatures`,children:`ArdoFeatures`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardofooter`,children:`ArdoFooter`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardoheader`,children:`ArdoHeader`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardohero`,children:`ArdoHero`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardohomepage`,children:`ArdoHomePage`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardoinfo`,children:`ArdoInfo`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardolayout`,children:`ArdoLayout`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardonote`,children:`ArdoNote`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardoprovider`,children:`ArdoProvider`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardosearch`,children:`ArdoSearch`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardosidebar`,children:`ArdoSidebar`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardositeconfigprovider`,children:`ArdoSiteConfigProvider`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardosteps`,children:`ArdoSteps`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotab`,children:`ArdoTab`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotablist`,children:`ArdoTabList`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotabpanel`,children:`ArdoTabPanel`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotabpanels`,children:`ArdoTabPanels`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotabs`,children:`ArdoTabs`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardothemetoggle`,children:`ArdoThemeToggle`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotip`,children:`ArdoTip`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardotoc`,children:`ArdoTOC`})}),`
`,(0,i.jsx)(t.li,{children:(0,i.jsx)(t.a,{href:`/api-reference/components/ardowarning`,children:`ArdoWarning`})}),`
`]}),`
`,(0,i.jsx)(t.h2,{id:`functions`,children:`Functions`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/functions/config-index`,children:`config/index`}),` - defineConfig, loadConfig, resolveConfig`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/functions/runtime-hooks`,children:`runtime/hooks`}),` - useArdoConfig, useArdoContext, useArdoLabels, useArdoPageData, useArdoSidebar, useArdoSiteConfig, useArdoTOC`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/functions/runtime-sidebar-utils`,children:`runtime/sidebar-utils`}),` - findCurrentSidebarItem, getPrevNextLinks`]}),`
`]}),`
`,(0,i.jsx)(t.h2,{id:`type-aliases`,children:`Type Aliases`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-codeblock`,children:`components/CodeBlock`}),` - ArdoCodeBlockProps, ArdoCodeGroupProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-container`,children:`components/Container`}),` - ArdoContainerProps, ArdoContainerType, ArdoDangerProps, ArdoInfoProps, ArdoNoteProps, ArdoTipProps, ArdoWarningProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-features`,children:`components/Features`}),` - ArdoFeatureCardProps, ArdoFeaturesProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-hero`,children:`components/Hero`}),` - ArdoHeroAction, ArdoHeroImage, ArdoHeroProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-steps`,children:`components/Steps`}),` - ArdoStepsProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/components-tabs`,children:`components/Tabs`}),` - ArdoTabListProps, ArdoTabPanelProps, ArdoTabPanelsProps, ArdoTabProps, ArdoTabsProps`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/config-types`,children:`config/types`}),` - ArdoBrandConfig, ArdoBrandHue, ArdoBrandHuePreset, ArdoBrandLogo, ArdoConfig, ContentValidationConfig, DiagnosticLevel, FrontmatterValidationConfig, HeadConfig, LlmsConfig, MarkdownConfig, OpenApiConfig, PageData, PageFrontmatter, ProjectMeta, ResolvedConfig, SidebarConfig, SidebarItem, SocialLink, TOCItem, TypeDocConfig`]}),`
`,(0,i.jsxs)(t.li,{children:[(0,i.jsx)(t.a,{href:`/api-reference/types/runtime-hooks`,children:`runtime/hooks`}),` - ArdoSiteConfig`]}),`
`]})]})}function c(e={}){let{wrapper:t}={...r(),...e.components};return t?(0,i.jsx)(t,{...e,children:(0,i.jsx)(s,{...e})}):s(e)}function l(e){return(0,i.jsx)(n,{frontmatter:o,toc:a,children:(0,i.jsx)(c,e)})}var u=e(l);export{u as default};