import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Ba4x_b3A.js";import"./chunk-I66GZJ75-DxVJmXXU.js";import"./chunk-NSK5VX7P-DdOwT8An.js";import"./chunk-4I5QYGJK-BcGGmTZt.js";import"./chunk-WRU74C26-DB5wccao.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CXy6Ti5I.js";import"./chunk-2GRJ4B5K-CpWmg5-S.js";import"./chunk-XXDRQBXY-CpXCxx_i.js";import"./chunk-KBJHAD2P-DDk3xU7o.js";import"./chunk-W5SLKNZC-DF8OLjlx.js";import"./chunk-QR6OTTB3-CXw6CXgr.js";import"./chunk-7Z6QIM7H-BP3omq3f.js";import{r as t,t as n}from"./chunk-JQJVKLGR-D6WWWbJu.js";import"./mermaid.core-MZ6G-wTK.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};