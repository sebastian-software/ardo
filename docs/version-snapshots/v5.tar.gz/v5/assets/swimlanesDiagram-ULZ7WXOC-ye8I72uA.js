import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Ca3cBOCh.js";import"./chunk-I66GZJ75-b6CAqesC.js";import"./chunk-NSK5VX7P-D_dQAU4-.js";import"./chunk-4I5QYGJK-D8ebTaAu.js";import"./chunk-WRU74C26-DPmCRt94.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-fy4ethP_.js";import"./chunk-2GRJ4B5K-D5P7dmBa.js";import"./chunk-XXDRQBXY-CBP1DWE5.js";import"./chunk-KBJHAD2P-BTPMN01N.js";import"./chunk-W5SLKNZC-XWq3r3TY.js";import"./chunk-QR6OTTB3-DFOZpmaq.js";import"./chunk-7Z6QIM7H-DwTtK0ae.js";import{r as t,t as n}from"./chunk-JQJVKLGR-BLYRoweN.js";import"./mermaid.core-BzgydUAr.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};