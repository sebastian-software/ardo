import{C as e,t}from"./jsx-runtime-kxZKpzum.js";import{U as n}from"./DocPage-Bo6wr0LH-BDDnOnlj.js";import{t as r}from"./provider-DsTz6XUy.js";var i=t(),a=[{id:`ardoheroaction`,text:`ArdoHeroAction`,level:2},{id:`ardoheroimage`,text:`ArdoHeroImage`,level:2},{id:`ardoheroprops`,text:`ArdoHeroProps`,level:2}],o={title:`components/Hero Types`,description:`Type definitions from ui/components/Hero.tsx`};function s(e){let t={a:`a`,code:`code`,h2:`h2`,hr:`hr`,p:`p`,...r(),...e.components};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(t.p,{children:[`Type definitions from `,(0,i.jsx)(t.code,{children:`ui/components/Hero.tsx`})]}),`
`,(0,i.jsx)(t.h2,{id:`ardoheroaction`,children:`ArdoHeroAction`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Hero.tsx#L9`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardoheroimage`,children:`ArdoHeroImage`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Hero.tsx#L20`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardoheroprops`,children:`ArdoHeroProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Hero.tsx#L29`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{})]})}function c(e={}){let{wrapper:t}={...r(),...e.components};return t?(0,i.jsx)(t,{...e,children:(0,i.jsx)(s,{...e})}):s(e)}function l(e){return(0,i.jsx)(n,{frontmatter:o,toc:a,children:(0,i.jsx)(c,e)})}var u=e(l);export{u as default};