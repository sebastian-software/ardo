import{C as e,t}from"./jsx-runtime-kxZKpzum.js";import{U as n}from"./DocPage-Bo6wr0LH-BDDnOnlj.js";import{t as r}from"./provider-DsTz6XUy.js";var i=t(),a=[{id:`the-problem-with-documentation-frameworks`,text:`The Problem with Documentation Frameworks`,level:2},{id:`what-makes-ardo-different`,text:`What Makes Ardo Different`,level:2},{id:`your-react-knowledge-applied-directly`,text:`Your React Knowledge, Applied Directly`,level:3},{id:`built-on-react-router-8`,text:`Built on React Router 8`,level:3},{id:`powered-by-vite`,text:`Powered by Vite`,level:3},{id:`what-you-get`,text:`What You Get`,level:2},{id:`markdown-react-components`,text:`Markdown + React Components`,level:3},{id:`a-polished-default-theme`,text:`A Polished Default Theme`,level:3},{id:`type-safe-styling-with-vanilla-extract`,text:`Type-Safe Styling with Vanilla Extract`,level:3},{id:`fully-customizable`,text:`Fully Customizable`,level:3},{id:`where-ardo-fits`,text:`Where Ardo Fits`,level:2},{id:`versioning-and-browser-support`,text:`Versioning and Browser Support`,level:2},{id:`getting-started`,text:`Getting Started`,level:2}],o={title:`What is Ardo?`,description:`A modern, open documentation framework for React teams that want static docs without leaving React.`,order:1};function s(e){let t={a:`a`,code:`code`,h2:`h2`,h3:`h3`,li:`li`,p:`p`,pre:`pre`,span:`span`,strong:`strong`,ul:`ul`,...r(),...e.components};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(t.p,{children:`You know React. You have components, providers, styling conventions, examples, and TypeScript types that already explain how your product works. Then documentation starts, and too often the docs stack asks you to learn a different component model before you can ship a useful guide.`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.strong,{children:`Ardo exists so you don't have to start over.`})}),`
`,(0,i.jsxs)(t.p,{children:[`It is a static documentation framework built on `,(0,i.jsx)(t.a,{href:`https://react.dev/`,children:`React`}),`, `,(0,i.jsx)(t.a,{href:`https://reactrouter.com/`,children:`React Router 8`}),`, and `,(0,i.jsx)(t.a,{href:`https://vite.dev/`,children:`Vite`}),`. It gives React teams a simple docs workflow without a closed platform, a second UI framework, or a docs-only component model.`]}),`
`,(0,i.jsx)(t.h2,{id:`the-problem-with-documentation-frameworks`,children:`The Problem with Documentation Frameworks`}),`
`,(0,i.jsx)(t.p,{children:`Most documentation tools ask you to leave your stack at the door. They come with their own component systems, their own conventions, and their own learning curves. That's fine if you're starting from scratch — but if you already live in the React ecosystem, it means:`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsx)(t.li,{children:`Rewriting components you already have`}),`
`,(0,i.jsx)(t.li,{children:`Learning patterns that don't transfer to your other work`}),`
`,(0,i.jsx)(t.li,{children:`Maintaining two mental models for the same kind of UI`}),`
`]}),`
`,(0,i.jsx)(t.p,{children:`Ardo takes a different approach. Instead of inventing a new system, it builds on top of what the React ecosystem already provides.`}),`
`,(0,i.jsx)(t.h2,{id:`what-makes-ardo-different`,children:`What Makes Ardo Different`}),`
`,(0,i.jsx)(t.h3,{id:`your-react-knowledge-applied-directly`,children:`Your React Knowledge, Applied Directly`}),`
`,(0,i.jsx)(t.p,{children:`Every component in Ardo is a React component. Your documentation layout, your custom callouts, your interactive API playgrounds — they're all standard React. Import any component from npm. Use the hooks you already know. Write TypeScript the way you always do.`}),`
`,(0,i.jsx)(t.p,{children:`There's nothing new to learn before you're productive.`}),`
`,(0,i.jsx)(t.h3,{id:`built-on-react-router-8`,children:`Built on React Router 8`}),`
`,(0,i.jsxs)(t.p,{children:[`Ardo doesn't reinvent routing. It uses `,(0,i.jsx)(t.a,{href:`https://reactrouter.com/`,children:`React Router 8`}),` — the same router that powers production React apps. This gives you file-based routing, static pre-rendering for fast page loads, type-safe navigation, and all the patterns from React 19.`]}),`
`,(0,i.jsx)(t.h3,{id:`powered-by-vite`,children:`Powered by Vite`}),`
`,(0,i.jsx)(t.p,{children:`Vite keeps the local editing loop fast, production builds optimized, and the plugin ecosystem open. Ardo adds documentation-specific processing on top of that instead of hiding Vite behind a separate platform.`}),`
`,(0,i.jsx)(t.h2,{id:`what-you-get`,children:`What You Get`}),`
`,(0,i.jsx)(t.h3,{id:`markdown-react-components`,children:`Markdown + React Components`}),`
`,(0,i.jsx)(t.p,{children:`Write documentation in Markdown, drop in React components where you need them:`}),`
`,(0,i.jsx)(i.Fragment,{children:(0,i.jsx)(t.pre,{className:`shiki shiki-themes github-light github-dark`,style:{"--shiki-light":`#24292e`,"--shiki-dark":`#e1e4e8`,"--shiki-light-bg":`#fff`,"--shiki-dark-bg":`#24292e`},tabIndex:`0`,children:(0,i.jsxs)(t.code,{children:[(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#005CC5`,"--shiki-light-font-weight":`bold`,"--shiki-dark":`#79B8FF`,"--shiki-dark-font-weight":`bold`},children:`# My Documentation`})}),`
`,(0,i.jsx)(t.span,{className:`line`}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`Regular markdown content...`})}),`
`,(0,i.jsx)(t.span,{className:`line`}),`
`,(0,i.jsxs)(t.span,{className:`line`,children:[(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`<`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#22863A`,"--shiki-dark":`#85E89D`},children:`CustomComponent`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#6F42C1`,"--shiki-dark":`#B392F0`},children:` prop`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`=`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#032F62`,"--shiki-dark":`#9ECBFF`},children:`"value"`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:` />`})]}),`
`,(0,i.jsx)(t.span,{className:`line`}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`More markdown content...`})})]})})}),`
`,(0,i.jsx)(t.p,{children:`No special syntax. No wrappers. Just MDX, the way it was designed to work.`}),`
`,(0,i.jsx)(t.h3,{id:`a-polished-default-theme`,children:`A Polished Default Theme`}),`
`,(0,i.jsx)(t.p,{children:`Ardo ships with a complete theme so you can focus on content, not design:`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsx)(t.li,{children:`Responsive layout that works on any device`}),`
`,(0,i.jsx)(t.li,{children:`Dark and light mode with automatic detection`}),`
`,(0,i.jsx)(t.li,{children:`Full-text search across all your pages`}),`
`,(0,i.jsx)(t.li,{children:`Automatic table of contents`}),`
`,(0,i.jsx)(t.li,{children:`Syntax highlighting with line numbers and highlights`}),`
`]}),`
`,(0,i.jsx)(t.h3,{id:`type-safe-styling-with-vanilla-extract`,children:`Type-Safe Styling with Vanilla Extract`}),`
`,(0,i.jsxs)(t.p,{children:[`Ardo's UI is built with `,(0,i.jsx)(t.a,{href:`https://vanilla-extract.style/`,children:`Vanilla Extract`}),` — a zero-runtime CSS-in-TypeScript solution. Every design token (colors, spacing, radii, transitions) is available as a type-safe import:`]}),`
`,(0,i.jsx)(i.Fragment,{children:(0,i.jsx)(t.pre,{className:`shiki shiki-themes github-light github-dark`,style:{"--shiki-light":`#24292e`,"--shiki-dark":`#e1e4e8`,"--shiki-light-bg":`#fff`,"--shiki-dark-bg":`#24292e`},tabIndex:`0`,children:(0,i.jsxs)(t.code,{children:[(0,i.jsxs)(t.span,{className:`line`,children:[(0,i.jsx)(t.span,{style:{"--shiki-light":`#D73A49`,"--shiki-dark":`#F97583`},children:`import`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:` { vars } `}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#D73A49`,"--shiki-dark":`#F97583`},children:`from`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#032F62`,"--shiki-dark":`#9ECBFF`},children:` "ardo/theme"`})]}),`
`,(0,i.jsx)(t.span,{className:`line`}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#6A737D`,"--shiki-dark":`#6A737D`},children:`// Full autocomplete for all design tokens`})}),`
`,(0,i.jsxs)(t.span,{className:`line`,children:[(0,i.jsx)(t.span,{style:{"--shiki-light":`#D73A49`,"--shiki-dark":`#F97583`},children:`const`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#005CC5`,"--shiki-dark":`#79B8FF`},children:` myStyle`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#D73A49`,"--shiki-dark":`#F97583`},children:` =`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#6F42C1`,"--shiki-dark":`#B392F0`},children:` style`}),(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`({`})]}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`  color: vars.color.brand,`})}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`  borderRadius: vars.radius.base,`})}),`
`,(0,i.jsx)(t.span,{className:`line`,children:(0,i.jsx)(t.span,{style:{"--shiki-light":`#24292E`,"--shiki-dark":`#E1E4E8`},children:`})`})})]})})}),`
`,(0,i.jsxs)(t.p,{children:[`The `,(0,i.jsx)(t.code,{children:`ardo()`}),` Vite plugin automatically includes the Vanilla Extract plugin, so you can write `,(0,i.jsx)(t.code,{children:`.css.ts`}),` files in your own project without any extra setup.`]}),`
`,(0,i.jsx)(t.h3,{id:`fully-customizable`,children:`Fully Customizable`}),`
`,(0,i.jsx)(t.p,{children:`When you're ready to make it yours, everything is accessible. Theme colors, layout components, Markdown processing, and the build pipeline are standard React and Vite pieces, so customization works the way your team already works.`}),`
`,(0,i.jsx)(t.h2,{id:`where-ardo-fits`,children:`Where Ardo Fits`}),`
`,(0,i.jsx)(t.p,{children:`Ardo is strongest when documentation should live next to a React codebase:`}),`
`,(0,i.jsxs)(t.ul,{children:[`
`,(0,i.jsx)(t.li,{children:`component libraries that need live examples and API reference pages;`}),`
`,(0,i.jsx)(t.li,{children:`product teams with an existing React design system;`}),`
`,(0,i.jsx)(t.li,{children:`open-source projects that want static docs without a hosted platform;`}),`
`,(0,i.jsx)(t.li,{children:`teams that like VitePress-style simplicity but do not want Vue or Astro as their docs runtime.`}),`
`]}),`
`,(0,i.jsx)(t.p,{children:`It is not trying to replace every docs tool. If you need mature versioning/i18n today, Docusaurus may fit better. If your docs are mostly prose and the smallest possible payload matters most, Starlight or VitePress may be better. If you want hosted analytics, AI features, and API playground management, Mintlify is a different category.`}),`
`,(0,i.jsxs)(t.p,{children:[`The `,(0,i.jsx)(t.a,{href:`/guide/status-roadmap`,children:`Feature Status`}),` page keeps that boundary explicit as shipped features and
roadmap items change.`]}),`
`,(0,i.jsx)(t.h2,{id:`versioning-and-browser-support`,children:`Versioning and Browser Support`}),`
`,(0,i.jsxs)(t.p,{children:[`Ardo's packages are released together with the same version so the framework, UI, runtime, and
scaffolding CLI stay aligned. See the package changelogs for release history:
`,(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/CHANGELOG.md`,children:`ardo`}),` and
`,(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/create-ardo/CHANGELOG.md`,children:`create-ardo`}),`.`]}),`
`,(0,i.jsx)(t.p,{children:`Ardo targets modern evergreen browsers supported by React 19 and Vite 8. The default theme uses
modern CSS such as OKLCH color and custom properties; teams with legacy browser requirements should
test their final docs build against their own support matrix.`}),`
`,(0,i.jsx)(t.h2,{id:`getting-started`,children:`Getting Started`}),`
`,(0,i.jsxs)(t.p,{children:[`Ready to try it? The `,(0,i.jsx)(t.a,{href:`/guide/getting-started`,children:`Getting Started`}),` guide walks you through setup in a few minutes.`]})]})}function c(e={}){let{wrapper:t}={...r(),...e.components};return t?(0,i.jsx)(t,{...e,children:(0,i.jsx)(s,{...e})}):s(e)}function l(e){return(0,i.jsx)(n,{frontmatter:o,toc:a,children:(0,i.jsx)(c,e)})}var u=e(l);export{u as default};