import{C as e,t}from"./jsx-runtime-kxZKpzum.js";import{U as n}from"./DocPage-Bo6wr0LH-BDDnOnlj.js";import{t as r}from"./provider-DsTz6XUy.js";var i=t(),a=[{id:`ardotablistprops`,text:`ArdoTabListProps`,level:2},{id:`ardotabpanelprops`,text:`ArdoTabPanelProps`,level:2},{id:`ardotabpanelsprops`,text:`ArdoTabPanelsProps`,level:2},{id:`ardotabprops`,text:`ArdoTabProps`,level:2},{id:`ardotabsprops`,text:`ArdoTabsProps`,level:2}],o={title:`components/Tabs Types`,description:`Type definitions from ui/components/Tabs.tsx`};function s(e){let t={a:`a`,code:`code`,h2:`h2`,hr:`hr`,p:`p`,...r(),...e.components};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(t.p,{children:[`Type definitions from `,(0,i.jsx)(t.code,{children:`ui/components/Tabs.tsx`})]}),`
`,(0,i.jsx)(t.h2,{id:`ardotablistprops`,children:`ArdoTabListProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Tabs.tsx#L94`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardotabpanelprops`,children:`ArdoTabPanelProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Tabs.tsx#L144`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardotabpanelsprops`,children:`ArdoTabPanelsProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Tabs.tsx#L176`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardotabprops`,children:`ArdoTabProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Tabs.tsx#L110`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{}),`
`,(0,i.jsx)(t.h2,{id:`ardotabsprops`,children:`ArdoTabsProps`}),`
`,(0,i.jsx)(t.p,{children:(0,i.jsx)(t.a,{href:`https://github.com/sebastian-software/ardo/blob/main/packages/ardo/ui/components/Tabs.tsx#L37`,children:`Source`})}),`
`,(0,i.jsx)(t.hr,{})]})}function c(e={}){let{wrapper:t}={...r(),...e.components};return t?(0,i.jsx)(t,{...e,children:(0,i.jsx)(s,{...e})}):s(e)}function l(e){return(0,i.jsx)(n,{frontmatter:o,toc:a,children:(0,i.jsx)(c,e)})}var u=e(l);export{u as default};