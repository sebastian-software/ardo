import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-C-8iy5ks.js";import"./chunk-WYO6CB5R-DiGiGk5K.js";import"./chunk-ICXQ74PX-CTvWJHCz.js";import"./chunk-HOUHSVGY-D8j74Gj0.js";import"./chunk-Q4XR5HBZ-CXLq3pC2.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-OGEWGWER-DpVS9Onk.js";import"./chunk-32BRIVSS-CsEOs_MH.js";import"./chunk-XXDRQBXY-DR4ZG7zu.js";import"./chunk-VR4S4FIN-DcIz1V1a.js";import"./chunk-C7G6YPKG-B026H4ux.js";import"./chunk-ZGVPDNZ5-D9F-4ewt.js";import"./chunk-52WLFC77-B52BE5CH.js";import"./chunk-FWX5IMBZ-B0vJ6gdV.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-PUDLZKDR-tL0Iowqx.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};